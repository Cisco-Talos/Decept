def inbound_hook(inbound_data):
    return inbound_data[0:666] 

def outbound_hook(outbound_data):
    return outbound_data[0:22] 
